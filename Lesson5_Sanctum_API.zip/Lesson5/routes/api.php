<?php

use App\Http\Controllers\Api\AuthTokenController;
use App\Http\Controllers\Api\ReportController;
use App\Http\Controllers\Api\StudentApiController;
use Illuminate\Support\Facades\Route;

// Step 3: issue a token (public - credentials are checked inside)
Route::post('/tokens/create', [AuthTokenController::class, 'create']);

// Step 4: everything below needs a valid bearer token
Route::middleware('auth:sanctum')->group(function () {
    // Step 7: revoke the token used for this request
    Route::post('/logout', [AuthTokenController::class, 'logout']);

    // Student endpoints
    Route::get('/students', [StudentApiController::class, 'index']);
    Route::get('/students/{student}', [StudentApiController::class, 'show']);
    Route::post('/students', [StudentApiController::class, 'store']);
    Route::put('/students/{student}', [StudentApiController::class, 'update']);
    Route::delete('/students/{student}', [StudentApiController::class, 'destroy']);

    // Step 5: reports (needs the reports:read ability)
    Route::get('/reports', [ReportController::class, 'index']);
});
