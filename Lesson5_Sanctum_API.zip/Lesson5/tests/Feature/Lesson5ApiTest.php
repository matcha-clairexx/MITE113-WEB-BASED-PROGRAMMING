<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/** One test per "You're done when" checkbox. */
class Lesson5ApiTest extends TestCase
{
    use RefreshDatabase;

    public function test_request_without_token_gets_401(): void
    {
        $this->getJson('/api/students')->assertUnauthorized();
    }

    public function test_valid_token_reaches_student_data(): void
    {
        $user = User::factory()->create(['password' => 'secret123']);

        $token = $this->postJson('/api/tokens/create', [
            'email' => $user->email, 'password' => 'secret123', 'device_name' => 'phone',
        ])->assertOk()->json('token');

        $this->withToken($token)->getJson('/api/students')->assertOk();
    }

    public function test_reports_only_token_is_blocked_from_write_routes(): void
    {
        $user = User::factory()->create();
        $token = $user->createToken('reports-bot', ['reports:read'])->plainTextToken;

        $this->withToken($token)->getJson('/api/reports')->assertOk();
        $this->withToken($token)
            ->postJson('/api/students', ['name' => 'X', 'email' => 'x@example.com'])
            ->assertForbidden();
    }

    public function test_revoked_token_no_longer_authenticates(): void
    {
        $user = User::factory()->create();
        $token = $user->createToken('phone')->plainTextToken;

        $this->withToken($token)->postJson('/api/logout')->assertOk();

        // Clear the cached guard user so the next request re-checks the DB
        $this->app['auth']->forgetGuards();

        $this->withToken($token)->getJson('/api/students')->assertUnauthorized();
    }
}
