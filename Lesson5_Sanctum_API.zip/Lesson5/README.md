# Lesson 5 Activity – Token-Protected API (Laravel Sanctum)

Builds on the Lesson 4 Student Manager (auth middleware + `StudentPolicy`).

## Files
| File | Step |
|---|---|
| `app/Models/User.php` | 2 – `HasApiTokens` trait |
| `app/Http/Controllers/Api/AuthTokenController.php` | 3 & 7 – issue / revoke token |
| `routes/api.php` | 3, 4, 5, 7 – routes under `auth:sanctum` |
| `app/Http/Controllers/Api/StudentApiController.php` | 4 – protected student endpoints |
| `app/Http/Controllers/Api/ReportController.php` | 5 – `tokenCan('reports:read')` |
| `tests/Feature/Lesson5ApiTest.php` | "You're done when" checks |

## Setup
```bash
php artisan install:api     # Step 1: installs Sanctum, runs personal_access_tokens migration, adds routes/api.php
```
Copy the files above into your project (merge `User.php` with your existing one - only the
`use Laravel\Sanctum\HasApiTokens;` line and `HasApiTokens` in the trait list are new).
Adjust the validated fields in `StudentApiController` to match your `students` table.

## Step 6 – Call the API (curl)
```bash
# 1. No token  -> 401
curl -i -H "Accept: application/json" http://localhost:8000/api/students

# 2. Get a full-access token
curl -X POST http://localhost:8000/api/tokens/create \
  -H "Accept: application/json" -H "Content-Type: application/json" \
  -d '{"email":"you@example.com","password":"password","device_name":"my-laptop"}'

# 3. With token -> 200
curl -i -H "Accept: application/json" -H "Authorization: Bearer <TOKEN>" http://localhost:8000/api/students

# 4. Scoped token (Step 5)
curl -X POST http://localhost:8000/api/tokens/create \
  -H "Accept: application/json" -H "Content-Type: application/json" \
  -d '{"email":"you@example.com","password":"password","device_name":"reports-bot","abilities":["reports:read"]}'

curl -i -H "Accept: application/json" -H "Authorization: Bearer <REPORTS_TOKEN>" http://localhost:8000/api/reports   # 200
curl -i -X POST -H "Accept: application/json" -H "Authorization: Bearer <REPORTS_TOKEN>" \
  -d '{"name":"Test","email":"t@example.com"}' http://localhost:8000/api/students                                    # 403

# 5. Revoke (Step 7), then retry -> 401
curl -X POST -H "Accept: application/json" -H "Authorization: Bearer <TOKEN>" http://localhost:8000/api/logout
curl -i -H "Accept: application/json" -H "Authorization: Bearer <TOKEN>" http://localhost:8000/api/students
```
Always send `Accept: application/json` so unauthenticated requests return a 401 instead of a redirect.

## Run the checks
```bash
php artisan test --filter=Lesson5ApiTest
```

## You're done when
- [x] No token -> 401
- [x] Valid bearer token -> student data
- [x] `reports:read` token -> 403 on write routes
- [x] Revoked token -> 401 on the next request
