<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Student;
use Illuminate\Http\Request;

/**
 * Adjust the validated fields to match your Lesson 4 students table.
 * Reuses the StudentPolicy from Lesson 4 via authorize().
 */
class StudentApiController extends Controller
{
    public function index(Request $request)
    {
        $this->authorize('viewAny', Student::class);
        return Student::all();
    }

    public function show(Request $request, Student $student)
    {
        $this->authorize('view', $student);
        return $student;
    }

    public function store(Request $request)
    {
        $this->denyUnlessAbility($request, 'students:write');
        $this->authorize('create', Student::class);

        $student = Student::create($request->validate([
            'name'   => 'required|string|max:255',
            'email'  => 'required|email|unique:students,email',
            'course' => 'nullable|string|max:255',
        ]));

        return response()->json($student, 201);
    }

    public function update(Request $request, Student $student)
    {
        $this->denyUnlessAbility($request, 'students:write');
        $this->authorize('update', $student);

        $student->update($request->validate([
            'name'   => 'sometimes|string|max:255',
            'email'  => 'sometimes|email|unique:students,email,' . $student->id,
            'course' => 'nullable|string|max:255',
        ]));

        return $student;
    }

    public function destroy(Request $request, Student $student)
    {
        $this->denyUnlessAbility($request, 'students:write');
        $this->authorize('delete', $student);

        $student->delete();
        return response()->noContent();
    }

    /** Scoped tokens (e.g. reports-bot) cannot hit write routes. */
    private function denyUnlessAbility(Request $request, string $ability): void
    {
        abort_unless($request->user()->tokenCan($ability), 403, 'Token lacks the ' . $ability . ' ability.');
    }
}
