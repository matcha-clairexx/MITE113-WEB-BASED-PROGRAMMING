<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Student;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    /** GET /api/reports - Step 5: requires the reports:read ability. */
    public function index(Request $request)
    {
        abort_unless($request->user()->tokenCan('reports:read'), 403, 'Token lacks the reports:read ability.');

        return response()->json(['total_students' => Student::count()]);
    }
}
