<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthTokenController extends Controller
{
    /**
     * POST /api/tokens/create
     * Body: email, password, device_name, [abilities[]]
     * Omit abilities for a full-access token; send e.g. ["reports:read"] for a scoped one.
     */
    public function create(Request $request)
    {
        $data = $request->validate([
            'email'       => 'required|email',
            'password'    => 'required',
            'device_name' => 'required|string',
            'abilities'   => 'sometimes|array',
            'abilities.*' => 'string',
        ]);

        $user = User::where('email', $data['email'])->first();

        if (! $user || ! Hash::check($data['password'], $user->password)) {
            return response()->json(['message' => 'Invalid credentials.'], 422);
        }

        $token = $user->createToken(
            $data['device_name'],
            $data['abilities'] ?? ['*']
        );

        return response()->json(['token' => $token->plainTextToken]);
    }

    /** POST /api/logout - revokes only the token that made this request. */
    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json(['message' => 'Token revoked.']);
    }
}
